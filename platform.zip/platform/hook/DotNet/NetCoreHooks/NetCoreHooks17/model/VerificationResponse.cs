﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreHooks.model
{
    public class VerificationResponse
    {
        public string Verification { get; set; }
    }
}
