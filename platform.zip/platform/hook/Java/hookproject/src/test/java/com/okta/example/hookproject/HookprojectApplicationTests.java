package com.okta.example.hookproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HookprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
