package com.okta.example.hookproject.model;

public class VerificationResponse {

    private String verification;

    public String getVerification() {
        return verification;
    }

    public void setVerification(String verification) {
        this.verification = verification;
    }

}
