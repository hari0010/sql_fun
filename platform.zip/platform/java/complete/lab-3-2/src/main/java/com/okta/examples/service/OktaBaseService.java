package com.okta.examples.service;

import com.fasterxml.jackson.databind.ObjectMapper;

public interface OktaBaseService {

    ObjectMapper mapper = new ObjectMapper();
}
