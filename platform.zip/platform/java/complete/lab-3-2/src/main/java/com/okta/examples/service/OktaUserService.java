package com.okta.examples.service;

import java.util.List;

public interface OktaUserService extends OktaBaseService {
    
}
