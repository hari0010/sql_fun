package com.okta.examples.service;

import com.okta.authn.sdk.AuthenticationException;
import com.okta.authn.sdk.resource.AuthenticationResponse;

public interface OktaAuthService {

}
